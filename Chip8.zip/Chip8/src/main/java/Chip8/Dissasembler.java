
package Chip8;

public class Dissasembler{ //cls instruccion en ensamblador 
    //private short pc; //pc= 0xff

    //Funcion SYS 
    public String sys(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        return String.format("SYS %02X%02X", x, lsb);
    }

    public String cls(byte msb, byte lsb){
        //return String.format("%04X: CLS", pc); //imprimir en mayusculas X y 04 4 letras
        return  "CLS";
    }

    public String ret(byte msb, byte lsb){
        return "RET";
    }

    //Funcion Jump
    public String jp(byte msb, byte lsb) { 
        var x=msb & 0x0F;
        return String.format("JP %02X%02X", x, lsb);
    }

     //Funcion CALL
    public String call(byte msb, byte lsb) { 
        var x= msb & 0x0F;
        return String.format("CALL %02X%02X", x, lsb); 
    }

    public String pcAddr(byte msb, byte lsb) {
        return String.format("%02X%02X: ", msb, lsb);
    }

    //3xkk - SE Vx, byte
    public String se_xb(byte msb, byte lsb){
        var x=msb & 0x0F;
        return String.format("SE V%1X, %02X", x, lsb);
    }

    //4xkk - SNE Vx, byte
    public String sne_xb(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        return String.format("SNE V%1X, %02X", x, lsb);
    } 
    
    //5xy0 - SE Vx, Vy
    public String se_xy(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        var y=(lsb >>> 4) & 0x0F;
        return String.format("SE V%1X, V%1X", x, y);
    }

    //6xkk - LD Vx, byte
    public String ld_xb(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        return String.format("LD V%1X, %02X", x, lsb);
    }   

    //7xkk - ADD Vx, byte
    public String add_xb(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        return String.format("ADD V%1X, %02X", x, lsb);
    }

    //8xy0 - LD Vx, Vy
    public String ld_xy(byte msb, byte lsb){  
        var x=msb & 0x0F;
        var y=(lsb >>> 4) & 0x0F;
        return String.format("LD V%1X, V%1X", x, y);
    }

    //8xy1 - OR Vx, Vy
    public String or_xy(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        var y=(lsb >>> 4) & 0x0F;
        return String.format("OR V%1X, V%1X", x, y);
    }

    //8xy2 - AND Vx, Vy
    public String and_xy(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        var y=(lsb >>> 4) & 0x0F;
        return String.format("AND V%1X, V%1X", x, y);
    }

    //8xy3 - XOR Vx, Vy
    public String xor_xy(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        var y=(lsb >>> 4) & 0x0F;
        return String.format("XOR V%1X, V%1X", x, y);
    } 

    //8xy4 - ADD Vx, Vy
    public String add_xy(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        var y=(lsb >>> 4) & 0x0F;
        return String.format("ADD V%1X, V%1X", x, y);
    }

    //8xy5 - SUB Vx, Vy
    public String sub_xy(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        var y=(lsb >>> 4) & 0x0F;
        return String.format("SUB V%1X, V%1X", x, y);
    }

    //8xy6 - SHR Vx {, Vy}
    public String shr_x(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        return String.format("SHR V%1X, %02X", x);
    }

    //8xy7 - SUBN Vx, Vy
    public String subn_xy(byte msb, byte lsb){
        var x=msb & 0x0F;
        var y=(lsb >>> 4) & 0x0F;
        return String.format("SUBN V%1X, V%1X", x, y);
    }

    //8xyE - SHL Vx {, Vy}
    public String shl_x(byte msb, byte lsb){  
        var x=msb & 0x0F;
        return String.format("SHL V%1X, %02X", x);
    }

    //9xy0 - SNE Vx, Vy
    public String sne_xy(byte msb, byte lsb){  
        var x=msb & 0x0F;
        var y=(lsb >>> 4) & 0x0F;
        return String.format("SNE V%1X, V%1X", x, y);
    }

    //Annn - LD I, addr
    public String ld_i(byte msb, byte lsb) { 
        var x=msb & 0x0F;
        return String.format("LD_I %02X%02X", x, lsb);
    }

    //Bnnn - JP V0, addr
    public String jp_v0(byte msb, byte lsb) { 
        var x=msb & 0x0F; 
        return String.format("JP_V0 %02X%02X", x, lsb);
    }

    //Cxkk - RND Vx, byte
    public String rnd_xb(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        return String.format("RND V%1X, %02X", x, lsb);
    }
    
//* //Dxyn - DRW Vx, Vy, nibble
    public String drw (byte msb, byte lsb){
        var x=msb & 0x0F; 
        //var y=lsb >>> 4; 
        var y=(lsb >>> 4) & 0x0F;
        var nibble=lsb & 0x0F; 
        return String.format("DRW V%1X, V%1X, %1X", x, y, nibble);
    }

    //Ex9E - SKP Vx    //solo x
    public String skp_x(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        return String.format("SKP_X V%1X", x);
    }

    //ExA1 - SKNP Vx   //solo x
    public String sknp_x(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        return String.format("SKNP_X V%1X", x);
    }

    //Fx07 - LD Vx, DT
    public String ld_xdt(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        return String.format("LD V%1X DT", x);
    }

     //Fx0A - LD Vx, K
    public String ld_xk(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        return String.format("LD V%1X K", x);
    }

    //Fx15 - LD DT, Vx
    public String ld_dtx(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        return String.format("LD DT V%1X", x);
    }

    //Fx18 - LD ST, Vx
    public String ld_stx(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        return String.format("LD ST V%1X", x);
    }

    //Fx1E - ADD I, Vx
    public String add_ix(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        return String.format("ADD I V%1X", x);
    }

    //Fx29 - LD F, Vx
    public String ld_fx(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        return String.format("LD F V%1X", x);
    }

    //Fx33 - LD B, Vx
    public String ld_bx(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        return String.format("LD B V%1X", x);
    }

    //Fx55 - LD [I], Vx
    public String ldix(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        return String.format("LD [I] V%1X", x);
    }

    //Fx65 - LD Vx, [I]
    public String ldxi(byte msb, byte lsb){ 
        var x=msb & 0x0F;
        return String.format("LD V%1X, [I]", x);
    }
    

}