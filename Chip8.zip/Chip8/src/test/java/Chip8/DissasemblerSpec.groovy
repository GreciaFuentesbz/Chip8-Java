
package Chip8;
import spock.lang.Specification

//Leer de un archivo e imprimir comando 
class DissasemblerSpec extends Specification{ //unidad de prueba //junit 

    def "SYS is decoded"(){
        setup:
        def app= new Disassembler()

        when:
        def result= app.sys((byte)0x3E, (byte)0x54)

        then:
        result == "0000: SYS 0E54"
    }
    
    def "Clear Screen is printed" (){
        setup:
        def app= new Dissasembler()

        when: 
        def result= app.cls()

        then:
        result == "0000: CLS"
    }

    def "Return is printed" (){
        setup:
        def app= new Dissasembler()

        when: 
        def result= app.ret()

        then:
        result == "0000: RET"
    }

    def "Jump is decoded" (){
        setup:
        def app= new Dissasembler()

        when: 
        def result= app.jp((byte)0x13, (byte)0x54)

        then:
        result == "0000: JP 0354"
    }

    //Cambiamos instruccion o mascaras 
    def "CALL is decoded" (){
        setup:
        def app= new Dissasembler()

        when: 
        def result= app.call((byte)0x13, (byte)0x54)

        then:
        result == "0000: CALL 0354"
    }

    def "SE_XB is decoded" (){
        setup:
        def app= new Dissasembler()

        when: 
        def result= app.se_xb((byte)0x3E, (byte)0x54)

        then:
        result == "0000: SE_XB VE, 54"
    }

    def "SNE_XB is decoded"(){
        setup:
        def app= new Dissasembler()

        when:
        def result= app.sne_xb((byte)0x4E, (byte)0x54)

        then:
        result == "0000: SNE_XB VE, 54" 
    }

    def "SE_XY is decoded"(){ //
        setup:
        def app= new Dissasembler()

        when:
        def result= app.se_xy((byte)0x5E, (byte)0x54) 

        then:
        result == "0000: SE_XY VE, V5" 
    }

    def "LD_XB is decoded"(){ //
        setup:
        def app= new Dissasembler()

        when:
        def result= app.ld_xb((byte)0x6E, (byte)0x54)

        then:
        result == "0000: LD_XB VE, 54" 
    }

    def "ADD_XB is decoded"(){
        setup;
        def app= new Dissasembler()

        when:
        def result= app.add_xb((byte)0x7E, (byte)0x54)

        then:
        result == "0000: ADD_XB VE, 54"
    }

    def "LD_XY is decoded"(){ //
        setup:
        def app= new Dissasembler()

        when:
        def result= app.ld_xy((byte)0x8E, (byte)0x54) 

        then:
        result == "0000: LD_XY VE, V5"
    }

    def "OR_XY is decoded"(){
        setup:
        def app= new Dissasembler()

        when:
        def result= app.or_xy((byte)0x8E, (byte)0x54) 

        then:
        result == "0000: OR_XY VE, V5" 
    }

    def "AND_XY is decoded"(){
        setup:
        def app= new Dissasembler()

        when:
        def result= app.and_xy((byte)0x8E, (byte)0x54) 

        then:
        result == "0000: AND_XY VE, V5" 
    }

    def "XOR_XY is decoded"(){
        setup:
        def app= new Dissasembler()

        when:
        def result= app.xor_xy((byte)0x8E, (byte)0x54) 

        then:
        result == "0000: XOR_XY VE, V5"  
    }

    def "ADD_XY is decoded"(){
        setup:
        def app= new Dissasembler()

        when:
        def result= app.add_xy((byte)0x8E, (byte)0x54) 

        then:
        result == "0000: ADD_XY VE, V5" 
    }

    def "SUB_XY is decoded"(){
        setup:
        def app= new Dissasembler()

        when:
        def result= app.sub_xy((byte)0x8E, (byte)0x54) 

        then:
        result == "0000: SUB_XY VE, V5"  
    }

    def "SHR_X is decoded"(){ // {, VY}
        setup:
        def app= new Dissasembler()

        when:
        def result= app.shr_x((byte)0x8E, (byte)0x54)

        then:
        result == "0000: SHR_X VE, V5" 
    }

    def "SUBN_XY is decoded"(){
        setup:
        def app= new Dissasembler()

        when:
        def result= app.subn_xy((byte)0x8E, (byte)0x54) 

        then:
        result == "0000: SUBN_XY VE, V5" 
    }

    def "SHL_X is decoded"(){
        setup:
        def app= new Dissasembler()

        when:
        def result= app.shl_x((byte)0x8E, (byte)0x54)

        then:
        result == "0000: SHL_X VE, V5" 
    }

    def "SNE_XY is decoded"(){
        setup:
        def app= new Dissasembler()

        when:
        def result= app.sne_xy((byte)0x9E, (byte)0x54) 

        then:
        result == "0000: SNE_XY VE, V5" 
    }

    def "LD_I is decoded"(){ //Address //**
        setup:
        def app= new Dissasembler()

        when:
        def result= app.ld_i((byte)0xAE, (byte)0x54)

        then:
        result == "0000: LD_I" 
    }

    def "JP_V0 is decoded"(){ //Address //**
        setup:
        def app= new Dissasembler()

        when:
        def result= app.jp_v0((byte)0xBE, (byte)0x54)

        then:
        result == "0000: JP_V0X" 
    }

    def "RND_XB is decoded"(){ 
        setup:
        def app= new Dissasembler()

        when:
        def result= app.rnd_xb((byte)0xCE, (byte)0x54)

        then:
        result == "0000: RND_XB VE, 54"
    }

    def "DRW is decoded" (){
        setup:
        def app= new Dissasembler()

        when: 
        def result= app.drw((byte)0xDE, (byte)0x54)

        then:
        result == "0000: DRW VE, V5, 4"
    }

    def "SKP_X is decoded"(){ // Solo VX resultado
        setup:
        def app= new Dissasembler()

        when:
        def result= app.skp_x((byte)0xEE, (byte)0x54)
        //def result = app.skp_x((byte)0xEE)
        then:
        result == "0000: SKP_X VE, 54 " 
        //result == "0000: SKNP_X VE, 54"
    }

    def "SKNP_X is decoded"(){ // Solo VX resultado
        setup:
        def app= new Dissasembler()

        when:
        def result= app.sknp_x((byte)0xEE, (byte)0x54)
    
        then:
        result == "0000: SKNP_X VE, 54" 
    }

    def "LD_XDT is decoded"(){ //*
        setup:
        def app= new Dissasembler()

        when:
        def result= app.ld_xdt((byte)0xFE)
        //def result = app.skp((byte)0xEE, (byte)0x54)
        then:
        result == "0000: LD_XDT VE, DT"
    }

    def "LD_XK is decoded"(){ //*
        setup:
        def app= new Dissasembler()

        when:
        def result= app.ld_xk((byte)0xFE)

        then:
        result == "0000: LD_XK VE, K"
    }

    def "LD_DTX is decoded"(){ //*
        setup:
        def app= new Dissasembler()

        when:
        def result= app.ld_dtx((byte)0xFE)

        then:
        result == "0000: LD_DTX DT, VE"
    }

    def "LD_STX is decoded"(){
        setup:
        def app= new Dissasembler()

        when:
        def result= app.ld_stx((byte)0xFE)

        then:
        result == "0000: LD_STX ST, VE" 
    }

    def "ADD_IX is decoded"(){
        setup:
        def app= new Dissasembler()

        when:
        def result= app.add_ix((byte)0xFE)

        then:
        result == "0000: ADD_IX I, VE" 
    }

    def "LD_FX is decoded"(){
        setup:
        def app= new Dissasembler()

        when:
        def result= app.ld_fx((byte)0xFE)

        then:
        result == "0000: LD_FX F, VE" 
    }

    def "LD_BX is decoded"(){
        setup:
        def app= new Dissasembler()

        when:
        def result= app.ld_bx((byte)0xFE)

        then:
        result == "0000: LD_BX B, VE" 
    }

    def "LD [I]x is decoded"(){
        setup:
        def app= new Dissasembler()

        when:
        def result= app.ldix((byte)0xFE)

        then:
        result == "0000: LD [I], VE" 
    }

    def "LD x[I] is decoded"(){ //*
        setup:
        def app= new Dissasembler()

        when:
        def result= app.ldxi((byte)0xFE)

        then:
        result == "0000: LD VE, [I]" 
    }

}
